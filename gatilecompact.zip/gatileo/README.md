# Gatileo_Pygame
Jogo em Pygame para a disciplina de Introdução à Logica e Programação. Info1.2025

Disciplina: Introdução à Logica e Programação
Alunos: Yasmim Emanuelly Felix Brasil e Juan Davi de Almeida Silva
Projeto: Gatíleo
Repositório: https://github.com/YasElly/Gatileo_Pygame.git
